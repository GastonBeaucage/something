[Gaston Beaucage], [A00867938], [1A], [2014-10-02]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[complete]

------------------------
Question two (SecondsConvert) status:

[complete]

------------------------
Question three (Arithemtic) status:

[complete]

------------------------
Question four (Cube) status:

[complete]

------------------------
Question five (Pie Chart) status:

[complete]
